from .sayhello import say_hello

print(say_hello("Srinivas"))